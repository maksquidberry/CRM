@extends('components.app')

@section('content')
    <livewire:auth-user/>
@endsection
