<?php $__env->startSection('content'); ?>
    <div class="w-100 d-flex flex-column">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-settings', [])->html();
} elseif ($_instance->childHasBeenRendered('AbVUSBO')) {
    $componentId = $_instance->getRenderedChildComponentId('AbVUSBO');
    $componentTag = $_instance->getRenderedChildComponentTagName('AbVUSBO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AbVUSBO');
} else {
    $response = \Livewire\Livewire::mount('user-settings', []);
    $html = $response->html();
    $_instance->logRenderedChild('AbVUSBO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-settings-password', [])->html();
} elseif ($_instance->childHasBeenRendered('JGHRM64')) {
    $componentId = $_instance->getRenderedChildComponentId('JGHRM64');
    $componentTag = $_instance->getRenderedChildComponentTagName('JGHRM64');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('JGHRM64');
} else {
    $response = \Livewire\Livewire::mount('user-settings-password', []);
    $html = $response->html();
    $_instance->logRenderedChild('JGHRM64', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.auth-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/d3011021/data/www/crm.pubble.systems/resources/views/components/user/settings.blade.php ENDPATH**/ ?>