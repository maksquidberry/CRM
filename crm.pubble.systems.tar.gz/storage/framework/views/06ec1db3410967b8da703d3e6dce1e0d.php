<?php $__env->startSection('content'); ?>
    <div class="w-100 d-flex flex-column">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-settings', [])->html();
} elseif ($_instance->childHasBeenRendered('YHJTGep')) {
    $componentId = $_instance->getRenderedChildComponentId('YHJTGep');
    $componentTag = $_instance->getRenderedChildComponentTagName('YHJTGep');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YHJTGep');
} else {
    $response = \Livewire\Livewire::mount('user-settings', []);
    $html = $response->html();
    $_instance->logRenderedChild('YHJTGep', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-settings-password', [])->html();
} elseif ($_instance->childHasBeenRendered('kfnd7oC')) {
    $componentId = $_instance->getRenderedChildComponentId('kfnd7oC');
    $componentTag = $_instance->getRenderedChildComponentTagName('kfnd7oC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('kfnd7oC');
} else {
    $response = \Livewire\Livewire::mount('user-settings-password', []);
    $html = $response->html();
    $_instance->logRenderedChild('kfnd7oC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.auth-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/crm.pubble.systems/resources/views/components/user/settings.blade.php ENDPATH**/ ?>