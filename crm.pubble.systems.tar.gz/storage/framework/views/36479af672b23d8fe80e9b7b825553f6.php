<?php $__env->startSection('content'); ?>
    <div class="w-100 text-white pb-3 d-flex flex-column">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-edit-item', ['userId' => $id])->html();
} elseif ($_instance->childHasBeenRendered('FN3hAAA')) {
    $componentId = $_instance->getRenderedChildComponentId('FN3hAAA');
    $componentTag = $_instance->getRenderedChildComponentTagName('FN3hAAA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FN3hAAA');
} else {
    $response = \Livewire\Livewire::mount('user-edit-item', ['userId' => $id]);
    $html = $response->html();
    $_instance->logRenderedChild('FN3hAAA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.auth-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/d301701/data/www/shaurma.holubets.pp.ua/resources/views/components/userEdit.blade.php ENDPATH**/ ?>