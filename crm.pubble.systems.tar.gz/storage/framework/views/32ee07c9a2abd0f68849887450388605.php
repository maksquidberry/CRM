<div class="col-12 mb-2">
    <div class="w-100 mt-3 dashboard__bg px-3 py-4">
        <div class="w-100">
            <div class="row">
                <div class="col-12">
                    <div class="w-100 d-flex">
                        <h6 class="fw-bold">Активні замовлення:</h6>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $orderList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('card-item', ['index' => ''.e($order->id).'','isActive' => true])->html();
} elseif ($_instance->childHasBeenRendered('l3202748599-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3202748599-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3202748599-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3202748599-0');
} else {
    $response = \Livewire\Livewire::mount('card-item', ['index' => ''.e($order->id).'','isActive' => true]);
    $html = $response->html();
    $_instance->logRenderedChild('l3202748599-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <script>
        setInterval(()=>{
            window.livewire.find('<?php echo e($_instance->id); ?>').render;
        }, 1000)
    </script>
</div>
<?php /**PATH /var/www/d301701/data/www/shaurma.holubets.pp.ua/resources/views/livewire/list-order-active.blade.php ENDPATH**/ ?>