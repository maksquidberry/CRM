<?php $__env->startSection('content'); ?>
    <div class="w-100 pb-3 d-flex flex-column">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('orders-block', [])->html();
} elseif ($_instance->childHasBeenRendered('ANS4IAW')) {
    $componentId = $_instance->getRenderedChildComponentId('ANS4IAW');
    $componentTag = $_instance->getRenderedChildComponentTagName('ANS4IAW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ANS4IAW');
} else {
    $response = \Livewire\Livewire::mount('orders-block', []);
    $html = $response->html();
    $_instance->logRenderedChild('ANS4IAW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.auth-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/d301701/data/www/shaurma.holubets.pp.ua/resources/views/components/user/orders.blade.php ENDPATH**/ ?>