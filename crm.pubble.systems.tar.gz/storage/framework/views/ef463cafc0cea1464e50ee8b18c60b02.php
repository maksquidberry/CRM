<?php $__env->startSection('content'); ?>
    <div class="w-100 dashboard__stats">
       
        <div class="dashboard__module w-100">
            <div class="w-100 dashboard__stats-inner">
                <div class="dashboard__stats-icon d-flex align-items-center justify-content-center">
                    <svg width="43" height="43" viewBox="0 0 43 43" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M33.5938 5.375H26.875C26.875 2.41035 24.4646 0 21.5 0C18.5354 0 16.125 2.41035 16.125 5.375H9.40625C7.18066 5.375 5.375 7.18066 5.375 9.40625V38.9688C5.375 41.1943 7.18066 43 9.40625 43H33.5938C35.8193 43 37.625 41.1943 37.625 38.9688V9.40625C37.625 7.18066 35.8193 5.375 33.5938 5.375ZM13.4375 35.6094C12.3205 35.6094 11.4219 34.7107 11.4219 33.5938C11.4219 32.4768 12.3205 31.5781 13.4375 31.5781C14.5545 31.5781 15.4531 32.4768 15.4531 33.5938C15.4531 34.7107 14.5545 35.6094 13.4375 35.6094ZM13.4375 27.5469C12.3205 27.5469 11.4219 26.6482 11.4219 25.5312C11.4219 24.4143 12.3205 23.5156 13.4375 23.5156C14.5545 23.5156 15.4531 24.4143 15.4531 25.5312C15.4531 26.6482 14.5545 27.5469 13.4375 27.5469ZM13.4375 19.4844C12.3205 19.4844 11.4219 18.5857 11.4219 17.4688C11.4219 16.3518 12.3205 15.4531 13.4375 15.4531C14.5545 15.4531 15.4531 16.3518 15.4531 17.4688C15.4531 18.5857 14.5545 19.4844 13.4375 19.4844ZM21.5 3.35938C22.617 3.35938 23.5156 4.25801 23.5156 5.375C23.5156 6.49199 22.617 7.39062 21.5 7.39062C20.383 7.39062 19.4844 6.49199 19.4844 5.375C19.4844 4.25801 20.383 3.35938 21.5 3.35938ZM32.25 34.2656C32.25 34.6352 31.9477 34.9375 31.5781 34.9375H19.4844C19.1148 34.9375 18.8125 34.6352 18.8125 34.2656V32.9219C18.8125 32.5523 19.1148 32.25 19.4844 32.25H31.5781C31.9477 32.25 32.25 32.5523 32.25 32.9219V34.2656ZM32.25 26.2031C32.25 26.5727 31.9477 26.875 31.5781 26.875H19.4844C19.1148 26.875 18.8125 26.5727 18.8125 26.2031V24.8594C18.8125 24.4898 19.1148 24.1875 19.4844 24.1875H31.5781C31.9477 24.1875 32.25 24.4898 32.25 24.8594V26.2031ZM32.25 18.1406C32.25 18.5102 31.9477 18.8125 31.5781 18.8125H19.4844C19.1148 18.8125 18.8125 18.5102 18.8125 18.1406V16.7969C18.8125 16.4273 19.1148 16.125 19.4844 16.125H31.5781C31.9477 16.125 32.25 16.4273 32.25 16.7969V18.1406Z" fill="#CAAC1F"/>
                    </svg>

                </div>
                <div class="d-flex flex-column">
                    <span class="dashboard__stats-label">Виконані:</span>
                    <span class="dashboard__stats-value"><?php echo e($completeOrders); ?> шт</span>
                </div>
            </div>
        </div>
        
        <div class="dashboard__module w-100">
            <div class="w-100 dashboard__stats-inner">
                <div class="dashboard__stats-icon d-flex align-items-center justify-content-center">
                    <svg width="43" height="42" viewBox="0 0 43 42" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_39_4)">
                            <mask id="mask0_39_4" style="mask-type:luminance" maskUnits="userSpaceOnUse" x="0" y="0" width="43" height="42">
                                <path d="M43 0H0V42H43V0Z" fill="white"/>
                            </mask>
                            <g mask="url(#mask0_39_4)">
                                <path d="M21.5 0.65625C9.99414 0.65625 0.671875 9.76172 0.671875 21C0.671875 32.2383 9.99414 41.3438 21.5 41.3438C33.0059 41.3438 42.3281 32.2383 42.3281 21C42.3281 9.76172 33.0059 0.65625 21.5 0.65625ZM26.2955 29.3754L18.8881 24.1172C18.6277 23.9285 18.4766 23.6332 18.4766 23.3215V9.51562C18.4766 8.97422 18.9301 8.53125 19.4844 8.53125H23.5156C24.0699 8.53125 24.5234 8.97422 24.5234 9.51562V20.8113L29.8564 24.6012C30.31 24.9211 30.4023 25.5363 30.0748 25.9793L27.7064 29.1621C27.3789 29.5969 26.749 29.6953 26.2955 29.3754Z" fill="#46D204"/>
                            </g>
                        </g>
                        <defs>
                            <clipPath id="clip0_39_4">
                                <rect width="43" height="42" fill="white"/>
                            </clipPath>
                        </defs>
                    </svg>
                </div>
                <div class="d-flex flex-column">
                    <span class="dashboard__stats-label">Середній час </span>
                    <span class="dashboard__stats-value"><?php echo e($timeTotalOrders); ?></span>
                </div>
            </div>
        </div>
    </div>
    <div class="w-100">
        <div class="w-100 dashboard__table mt-3 ">
            <div class="w-100 dashboard__table-header d-flex justify-content-between align-items-center">
                <span class="fw-bold text-uppercase">Всі замовлення</span>
                <div class="dashboard__table-counter">
                    <span>Замовлень:</span>
                    <span><?php echo e($allOrdersCount); ?></span>
                </div>
            </div>
        </div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('all-order-list', [])->html();
} elseif ($_instance->childHasBeenRendered('1JLIkbF')) {
    $componentId = $_instance->getRenderedChildComponentId('1JLIkbF');
    $componentTag = $_instance->getRenderedChildComponentTagName('1JLIkbF');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('1JLIkbF');
} else {
    $response = \Livewire\Livewire::mount('all-order-list', []);
    $html = $response->html();
    $_instance->logRenderedChild('1JLIkbF', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.auth-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/crm.pubble.systems/resources/views/components/user/dashboard.blade.php ENDPATH**/ ?>