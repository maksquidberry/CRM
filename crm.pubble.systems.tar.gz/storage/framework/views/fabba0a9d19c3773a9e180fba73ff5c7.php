<div class="col-lg-4 col-md-6">
    <div class="w-100 stats__block h-100 d-flex flex-column justify-content-between position-relative py-3">
       
        <div class="w-100 d-flex flex-column">
            <div class="w-100 mt-2 d-flex justify-content-between px-2">
                <span>Заказ №<b><?php echo e($order->code); ?></b></span>
                <span><?php echo e($order->start_order); ?></span>
            </div>

            <div class="mt-2 d-flex flex-column px-2">
                <span>Состав:</span>
                <div class="w-100 stats__items">
                    <span>Шаурма Mini <b>3шт</b></span>
                    <span>Шаурма Standart <b>5шт</b></span>
                    <span>Шаурма Standart <b>5шт</b></span>
                </div>
            </div>
        </div>

        <div class="w-100 d-flex px-2 mt-4">
            <?php if(!$isActive): ?>
                <button class="btn login__btns-submit" wire:click.prevent="takeOrder">
                    Взять в работу
                </button>

            <?php else: ?>
                <button class="btn login__btns-submit" wire:click.prevent="compleatOrder">
                    Завершить
                </button>
            <?php endif; ?>

        </div>
    </div>


</div>
<?php /**PATH D:\Projects\DigitalLab\shaurma-crm\resources\views/livewire/card-item.blade.php ENDPATH**/ ?>