<div class="w-100 mt-4">
    <div class="w-100 dashboard__table">
        <div class="w-100 dashboard__table-header d-flex justify-content-between align-items-center">
            <span class="fw-bold text-uppercase">Замолення в черзі</span>
            <div class="dashboard__table-counter">
                <span>Очікує:</span>
                <span><?php echo e(count($orderList)); ?></span>
            </div>
        </div>
        <div class="dashboard__table-items px-3 py-2">
            <?php $__currentLoopData = $orderList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="dashboard__table-item d-flex justify-content-between align-items-center">
                    <span class="fw-bold">Замовлення №<?php echo e($order->code); ?></span>
                    <span class="fw-bold"><?php echo e(\Carbon\Carbon::parse($order->created_at)->format('H:i')); ?></span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH /var/www/d301701/data/www/shaurma.holubets.pp.ua/resources/views/livewire/new-orders-list.blade.php ENDPATH**/ ?>