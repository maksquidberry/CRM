<?php $__env->startSection('content'); ?>
    <div class="ww-100 text-white pb-3 d-flex flex-column">
        <?php if(intval($id) > 0): ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('resotran-edit-item', ['userId' => $id])->html();
} elseif ($_instance->childHasBeenRendered('dbJb2Xl')) {
    $componentId = $_instance->getRenderedChildComponentId('dbJb2Xl');
    $componentTag = $_instance->getRenderedChildComponentTagName('dbJb2Xl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dbJb2Xl');
} else {
    $response = \Livewire\Livewire::mount('resotran-edit-item', ['userId' => $id]);
    $html = $response->html();
    $_instance->logRenderedChild('dbJb2Xl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php else: ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('resotran-edit-item', ['userId' => null])->html();
} elseif ($_instance->childHasBeenRendered('DU8LON5')) {
    $componentId = $_instance->getRenderedChildComponentId('DU8LON5');
    $componentTag = $_instance->getRenderedChildComponentTagName('DU8LON5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('DU8LON5');
} else {
    $response = \Livewire\Livewire::mount('resotran-edit-item', ['userId' => null]);
    $html = $response->html();
    $_instance->logRenderedChild('DU8LON5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.auth-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/d3011021/data/www/crm.pubble.systems/resources/views/components/retoranEdit.blade.php ENDPATH**/ ?>