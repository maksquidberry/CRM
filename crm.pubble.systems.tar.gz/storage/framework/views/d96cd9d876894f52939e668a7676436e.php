<?php $__env->startSection('content'); ?>
    <div class="ww-100 text-white pb-3 d-flex flex-column">
        <?php if(intval($id) > 0): ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-edit-item', ['userId' => $id])->html();
} elseif ($_instance->childHasBeenRendered('WYfzFKk')) {
    $componentId = $_instance->getRenderedChildComponentId('WYfzFKk');
    $componentTag = $_instance->getRenderedChildComponentTagName('WYfzFKk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('WYfzFKk');
} else {
    $response = \Livewire\Livewire::mount('user-edit-item', ['userId' => $id]);
    $html = $response->html();
    $_instance->logRenderedChild('WYfzFKk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php else: ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-edit-item', ['userId' => null])->html();
} elseif ($_instance->childHasBeenRendered('be97KBG')) {
    $componentId = $_instance->getRenderedChildComponentId('be97KBG');
    $componentTag = $_instance->getRenderedChildComponentTagName('be97KBG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('be97KBG');
} else {
    $response = \Livewire\Livewire::mount('user-edit-item', ['userId' => null]);
    $html = $response->html();
    $_instance->logRenderedChild('be97KBG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.auth-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/crm.pubble.systems/resources/views/components/userEdit.blade.php ENDPATH**/ ?>