<div class="w-100 text-white">
    <table class="w-100 mt-3">
        <thead class="table__header-user">
        <td>№</td>
        <td>Название</td>
        <td>Описание</td>
        <td>Код</td>
        <td></td>
        </thead>

        <tbody class="table__body-user">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="border-bottom: 1px solid white">
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->description); ?></td>
                <td><?php echo e($user->xml_id); ?></td>
                <td>
                    <a href="<?php echo e(route('restoran-edit', ['id' => $user->id])); ?>" class="text-info"> Ред.</a>
                    <a href="javascript:void(0)" wire:click.prevent="deleteUser(<?php echo e($user->id); ?>)" class="text-danger ms-2"> Удал.</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /var/www/d3011021/data/www/crm.pubble.systems/resources/views/livewire/restoran-list-table.blade.php ENDPATH**/ ?>