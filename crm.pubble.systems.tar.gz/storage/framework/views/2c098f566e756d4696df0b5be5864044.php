<?php $__env->startSection('content'); ?>
    <div class="w-100 pb-3 d-flex flex-column">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('orders-block', [])->html();
} elseif ($_instance->childHasBeenRendered('4yKpuuL')) {
    $componentId = $_instance->getRenderedChildComponentId('4yKpuuL');
    $componentTag = $_instance->getRenderedChildComponentTagName('4yKpuuL');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4yKpuuL');
} else {
    $response = \Livewire\Livewire::mount('orders-block', []);
    $html = $response->html();
    $_instance->logRenderedChild('4yKpuuL', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>

    <script>
        setTimeout(() => {
            window.location.reload()
        }, 10000)
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.auth-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/d3011021/data/www/crm.pubble.systems/resources/views/components/user/orders.blade.php ENDPATH**/ ?>