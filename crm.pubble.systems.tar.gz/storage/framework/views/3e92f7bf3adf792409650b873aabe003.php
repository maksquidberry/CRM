<div class="col-12">
    <div class="w-100 mt-3 dashboard__bg px-3 py-4">
        <div class="w-100">
            <div class="row">
                <div class="col-12">
                    <div class="w-100 d-flex">
                        <h6 class="fw-bold">Нові замовлення:</h6>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $orderList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('card-item', ['index' => ''.e($order->id).'','isActive' => false])->html();
} elseif ($_instance->childHasBeenRendered('l2610083371-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2610083371-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2610083371-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2610083371-0');
} else {
    $response = \Livewire\Livewire::mount('card-item', ['index' => ''.e($order->id).'','isActive' => false]);
    $html = $response->html();
    $_instance->logRenderedChild('l2610083371-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <script>
        setInterval(()=>{
            window.livewire.find('<?php echo e($_instance->id); ?>').render;
        }, 1000)
    </script>
</div>
<?php /**PATH /var/www/d301701/data/www/shaurma.holubets.pp.ua/resources/views/livewire/order-list-new.blade.php ENDPATH**/ ?>