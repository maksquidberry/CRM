<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('auth-user', [])->html();
} elseif ($_instance->childHasBeenRendered('g0rGBJ1')) {
    $componentId = $_instance->getRenderedChildComponentId('g0rGBJ1');
    $componentTag = $_instance->getRenderedChildComponentTagName('g0rGBJ1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('g0rGBJ1');
} else {
    $response = \Livewire\Livewire::mount('auth-user', []);
    $html = $response->html();
    $_instance->logRenderedChild('g0rGBJ1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\DigitalLab\shaurma-crm\resources\views/welcome.blade.php ENDPATH**/ ?>