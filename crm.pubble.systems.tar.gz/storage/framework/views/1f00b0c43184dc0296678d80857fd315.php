<div class="w-100 mt-4">
    <div class="w-100 dashboard__table">
        <div class="w-100 dashboard__table-header d-flex justify-content-between align-items-center">
            <span class="fw-bold text-uppercase">Мої замовлення в роботі</span>
            <div class="dashboard__table-counter">
                <span>В роботі:</span>
                <span><?php echo e(count($orderList)); ?></span>
            </div>
        </div>
        <div class="dashboard__table-items px-3 py-2">
            <?php $__currentLoopData = $orderList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="dashboard__table-item d-flex justify-content-between align-items-center">
                    <span class="fw-bold">Замовлення №<?php echo e($order->code); ?></span>
                    <div>
                        <span class="fw-bold"><?php echo e(\Carbon\Carbon::parse($order->created_at)->format('H:i')); ?></span>

                        <?php
                            $timeOrder = \Carbon\Carbon::parse($order?->start_cook_order);
                            $now = \Carbon\Carbon::now();

                            $time = $now->diff($timeOrder);
                        ?>
                        <span class="<?php if($time->i > 15): ?> text-danger <?php endif; ?> <?php if($time->h > 0): ?> text-danger <?php endif; ?>">(<?php echo e($time->h); ?>г <?php echo e($time->i); ?>хв <?php echo e($time->s); ?>с)</span>
                    </div>
                    <span class="text-uppercase fw-bold">
                        <?php switch($order->status):
                            case ('cooking'): ?>
                                Готується
                                <?php break; ?>
                            <?php case ('packing'): ?>
                                Пакується
                                <?php break; ?>
                            <?php case ('complete'): ?>
                                Готовий
                                <?php break; ?>
                            <?php case ('new'): ?>
                                Новий
                                <?php break; ?>
                        <?php endswitch; ?>
                    </span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH /var/www/d301701/data/www/shaurma.holubets.pp.ua/resources/views/livewire/my-orders-list.blade.php ENDPATH**/ ?>