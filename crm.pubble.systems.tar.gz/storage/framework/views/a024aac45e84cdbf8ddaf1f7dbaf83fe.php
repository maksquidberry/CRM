<div class="container-fluid container-lg mt-4">
    <div class="row">
        <div class="col-12">
            <div class="w-100 dashboard__header py-3 px-3 ps-4">
                <div class="w-100 d-flex justify-content-between">
                    <div class="d-flex flex-column flex-lg-row align-items-lg-center">
                        <div class="w-100 d-lg-flex d-none">
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.links','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('links'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        </div>
                        <a class="d-block d-lg-none" data-bs-toggle="offcanvas" href="#offcanvasExample" role="button" aria-controls="offcanvasExample">
                            <svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M2.9552 17.8467H15.7648C15.8471 17.8467 15.9285 17.8306 16.0046 17.7991C16.0806 17.7677 16.1497 17.7215 16.2079 17.6633C16.2661 17.6052 16.3122 17.5361 16.3437 17.46C16.3751 17.384 16.3913 17.3025 16.3912 17.2202V15.3481C16.3913 15.2659 16.3751 15.1844 16.3437 15.1083C16.3122 15.0323 16.2661 14.9632 16.2079 14.905C16.1497 14.8468 16.0806 14.8007 16.0046 14.7692C15.9285 14.7378 15.8471 14.7216 15.7648 14.7217H2.9552C2.87291 14.7216 2.79142 14.7378 2.71539 14.7692C2.63935 14.8007 2.57027 14.8468 2.51208 14.905C2.45389 14.9632 2.40775 15.0323 2.37629 15.1083C2.34483 15.1844 2.32867 15.2659 2.32874 15.3481V17.2202C2.32867 17.3025 2.34483 17.384 2.37629 17.46C2.40775 17.5361 2.45389 17.6052 2.51208 17.6633C2.57027 17.7215 2.63935 17.7677 2.71539 17.7991C2.79142 17.8306 2.87291 17.8467 2.9552 17.8467ZM2.9552 5.34668H15.7648C15.8471 5.34674 15.9285 5.33058 16.0046 5.29912C16.0806 5.26766 16.1497 5.22152 16.2079 5.16334C16.2661 5.10515 16.3122 5.03606 16.3437 4.96003C16.3751 4.88399 16.3913 4.8025 16.3912 4.72021V2.84814C16.3913 2.76586 16.3751 2.68437 16.3437 2.60833C16.3122 2.5323 16.2661 2.46321 16.2079 2.40502C16.1497 2.34684 16.0806 2.3007 16.0046 2.26924C15.9285 2.23778 15.8471 2.22162 15.7648 2.22168H2.9552C2.87291 2.22162 2.79142 2.23778 2.71539 2.26924C2.63935 2.3007 2.57027 2.34684 2.51208 2.40502C2.45389 2.46321 2.40775 2.5323 2.37629 2.60833C2.34483 2.68437 2.32867 2.76586 2.32874 2.84814V4.72021C2.32867 4.8025 2.34483 4.88399 2.37629 4.96003C2.40775 5.03606 2.45389 5.10515 2.51208 5.16334C2.57027 5.22152 2.63935 5.26766 2.71539 5.29912C2.79142 5.33058 2.87291 5.34674 2.9552 5.34668ZM23.4225 8.47168H3.10999C2.90279 8.47168 2.70407 8.55399 2.55756 8.7005C2.41105 8.84702 2.32874 9.04573 2.32874 9.25293V10.8154C2.32874 11.0226 2.41105 11.2213 2.55756 11.3679C2.70407 11.5144 2.90279 11.5967 3.10999 11.5967H23.4225C23.6297 11.5967 23.8284 11.5144 23.9749 11.3679C24.1214 11.2213 24.2037 11.0226 24.2037 10.8154V9.25293C24.2037 9.04573 24.1214 8.84702 23.9749 8.7005C23.8284 8.55399 23.6297 8.47168 23.4225 8.47168ZM23.4225 20.9717H3.10999C2.90279 20.9717 2.70407 21.054 2.55756 21.2005C2.41105 21.347 2.32874 21.5457 2.32874 21.7529V23.3154C2.32874 23.5226 2.41105 23.7213 2.55756 23.8679C2.70407 24.0144 2.90279 24.0967 3.10999 24.0967H23.4225C23.6297 24.0967 23.8284 24.0144 23.9749 23.8679C24.1214 23.7213 24.2037 23.5226 24.2037 23.3154V21.7529C24.2037 21.5457 24.1214 21.347 23.9749 21.2005C23.8284 21.054 23.6297 20.9717 23.4225 20.9717Z" fill="black"/>
                            </svg>
                        </a>
                    </div>
                    <div class="d-flex">
                        <?php if(auth()->user()->role ==='superadmin'): ?>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('clean-btn-item', [])->html();
} elseif ($_instance->childHasBeenRendered('gwPlkAJ')) {
    $componentId = $_instance->getRenderedChildComponentId('gwPlkAJ');
    $componentTag = $_instance->getRenderedChildComponentTagName('gwPlkAJ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('gwPlkAJ');
} else {
    $response = \Livewire\Livewire::mount('clean-btn-item', []);
    $html = $response->html();
    $_instance->logRenderedChild('gwPlkAJ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        <?php endif; ?>
                        <a href="<?php echo e(route('exit')); ?>" class="dashboard__header-exit">Вийти</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasExampleLabel"></h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <div class="w-100 d-flex flex-column px-2">
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.links','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('links'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /var/www/d3011021/data/www/crm.pubble.systems/resources/views/components/navigation.blade.php ENDPATH**/ ?>