<div class="counter-list-item position-absolute" wire:poll.1000ms>
    <span class="counter-list-item_text"><?php echo e($list_count); ?></span>
</div>
<?php /**PATH /www/wwwroot/crm.pubble.systems/resources/views/livewire/counter-item-list.blade.php ENDPATH**/ ?>