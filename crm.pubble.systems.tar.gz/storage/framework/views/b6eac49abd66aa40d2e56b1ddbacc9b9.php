<div class="w-100 login d-flex align-items-center justify-content-center">
    <div class="container h-100">
        <div class="row h-100 d-flex align-items-center justify-content-center">
            <div class="col-lg-4 col-xl-3 col-md-5 col-md-8 col-12">
                <div class="w-100 login__inner">
                    <div class="w-100 d-flex justify-content-center">
                        <h5 class="fw-bold text-white text-uppercase">Вход</h5>
                    </div>

                    <form action="" wire:submit.prevent="checkUser" id="login" class="w-100 mt-1 d-flex flex-column">
                        <div class="w-100 d-flex flex-column">
                            <span class="fs-6 text-white">Логин</span>
                            <input type="text" name="login" wire:model="name" class="login__input">
                        </div>
                        <div class="w-100 mt-2 d-flex flex-column">
                            <span class="fs-6 text-white">Пароль</span>
                            <input type="password" name="password" wire:model="password" class="login__input">
                        </div>
                        <div class="w-100 login__btns mt-4">
                            <button type="submit" class="login__btns-submit login__btns-item w-100">Войти</button>
                            <button type="reset" class="login__btns-reset login__btns-item w-100">Очистить</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Projects\DigitalLab\shaurma-crm\resources\views/livewire/auth-user.blade.php ENDPATH**/ ?>