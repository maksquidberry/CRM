<div class="w-100 d-flex flex-column">
    <div class="w-100 dashboard__bg">
        <div class="w-100 d-flex justify-content-center">
            <span id="time__clock" class="clock text-white fs-1 fw-bold"><?=date('H:i:s')?></span>
        </div>
    </div>

    <div class="w-100  mt-3 dashboard__bg px-3 py-3">
        <div class="w-100 d-flex flex-column">
            <div class="w-100 d-flex justify-content-center">
                <h4 class="text-white fs-4 m-0 p-0">Особисті данні</h4>
            </div>
            <div class="w-100 d-flex flex-column mt-3">
                <div class="d-flex flex-column w-100">
                    <span class="fs-6 m-0 p-0">Користувач</span>
                    <span class="fs-5 fw-bold m-0 p-0"><?php echo e(auth()->user()->name); ?></span>
                </div>
                <div class="d-flex flex-column w-100 mt-2">
                    <span class="fs-6 m-0 p-0">Посада</span>
                    <span class="fs-5 fw-bold m-0 p-0">
                        <?php switch(auth()->user()->role):
                            case ('cook'): ?>
                                Повар
                                <?php break; ?>

                            <?php case ('pack'): ?>
                                Упаковщик
                                <?php break; ?>
                        <?php endswitch; ?>
                    </span>
                </div>
            </div>
        </div>
    </div>

    <script>
        var span = document.getElementById('time__clock');

        function time() {
            var d = new Date();
            var s = d.getSeconds();
            var m = d.getMinutes();
            var h = d.getHours();
            span.textContent =
                ("0" + h).substr(-2) + ":" + ("0" + m).substr(-2) + ":" + ("0" + s).substr(-2);
        }

        setInterval(time, 1000);
    </script>
</div>
<?php /**PATH D:\Projects\DigitalLab\shaurma-crm\resources\views/livewire/user-stats-info.blade.php ENDPATH**/ ?>