<div class="w-100 d-flex flex-column">
    <form class="w-100">
        <div class="row">
            <div class="col-12">
                <h1>Заведения</h1>
            </div>

            <?php if($errors->any()): ?>
                <div class="col-12 mb-2">
                    <?php echo e(implode('', $errors->all('<div>:message</div>'))); ?>

                </div>
            <?php endif; ?>

            <div class="col-lg-12 mb-2">
                <div class="w-100 d-flex flex-column">
                    <span>Названиe</span>
                    <input type="text" wire:model="restoran.name" class="w-100 d-flex user__input">
                </div>
            </div>
            <div class="col-lg-12 mb-2">
                <div class="w-100 d-flex flex-column">
                    <span>Описание</span>
                    <input type="text" wire:model="restoran.description" class="w-100 d-flex user__input">
                </div>
            </div>

            <div class="col-12 mt-3">
                <div class="w-100">
                    <button class="dashboard__btns-red px-5" wire:click.prevent="saveUser">Сохранить</button>
                    <a href="<?php echo e(route('users')); ?>" class="dashboard__btns-yellow px-5 ms-2">Назад</a>
                </div>
            </div>



        </div>
    </form>

    <?php if($isEditMode): ?>
        <div class="col-12 mt-2">
            <h4>Новый пользователь:</h4>
        </div>

        <div class="col-12 mt-2">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-restoran-form', ['id' => $restoran->id])->html();
} elseif ($_instance->childHasBeenRendered('l1730718750-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1730718750-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1730718750-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1730718750-0');
} else {
    $response = \Livewire\Livewire::mount('user-restoran-form', ['id' => $restoran->id]);
    $html = $response->html();
    $_instance->logRenderedChild('l1730718750-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-restoran-list', ['idGroup' => $restoran->id])->html();
} elseif ($_instance->childHasBeenRendered('l1730718750-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l1730718750-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1730718750-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1730718750-1');
} else {
    $response = \Livewire\Livewire::mount('user-restoran-list', ['idGroup' => $restoran->id]);
    $html = $response->html();
    $_instance->logRenderedChild('l1730718750-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.addEventListener('saveUser', (e) => {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
            })

            Toast.fire({
                icon: 'success',
                title: 'Сохранено'
            })
        })
    </script>
</div>
<?php /**PATH /var/www/d3011021/data/www/crm.pubble.systems/resources/views/livewire/resotran-edit-item.blade.php ENDPATH**/ ?>