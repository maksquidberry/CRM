<div class="w-100 d-flex flex-column" >
    

    <div class="w-100"  wire:poll.3000ms>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('my-orders-tabs', [])->html();
} elseif ($_instance->childHasBeenRendered(time())) {
    $componentId = $_instance->getRenderedChildComponentId(time());
    $componentTag = $_instance->getRenderedChildComponentTagName(time());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(time());
} else {
    $response = \Livewire\Livewire::mount('my-orders-tabs', []);
    $html = $response->html();
    $_instance->logRenderedChild(time(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <?php if(Auth::user()->role !== 'packer'): ?>
        <div class="w-100"  wire:poll.3000ms>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('new-orders-tabs', [])->html();
} elseif ($_instance->childHasBeenRendered(time())) {
    $componentId = $_instance->getRenderedChildComponentId(time());
    $componentTag = $_instance->getRenderedChildComponentTagName(time());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(time());
} else {
    $response = \Livewire\Livewire::mount('new-orders-tabs', []);
    $html = $response->html();
    $_instance->logRenderedChild(time(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
        <?php endif; ?>
</div>
<?php /**PATH /var/www/d301701/data/www/shaurma.holubets.pp.ua/resources/views/livewire/orders-block.blade.php ENDPATH**/ ?>