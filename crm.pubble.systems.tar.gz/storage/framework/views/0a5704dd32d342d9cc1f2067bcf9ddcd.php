<?php $__env->startSection('content'); ?>
    <div class="w-100 text-white pb-3 d-flex flex-column">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-list-table', [])->html();
} elseif ($_instance->childHasBeenRendered('akFvBAy')) {
    $componentId = $_instance->getRenderedChildComponentId('akFvBAy');
    $componentTag = $_instance->getRenderedChildComponentTagName('akFvBAy');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('akFvBAy');
} else {
    $response = \Livewire\Livewire::mount('user-list-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('akFvBAy', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.auth-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/d301701/data/www/shaurma.holubets.pp.ua/resources/views/components/userlist.blade.php ENDPATH**/ ?>