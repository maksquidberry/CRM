<div class="col-12">
    <div class="w-100">
        <table class="w-100 table table-border text-white">
            <tr>
                <td class="w-25"><?php echo e($item->name); ?></td>
                <td class="w-25"><?php echo e($item->description); ?></td>
                <td class="w-25"><?php echo e($item->xml_id); ?></td>
                <td class="w-25 text-end"><a href="" wire:click.prevent="delete" class="text-warning">Удалить</a></td>
            </tr>
        </table>
    </div>
</div>
<?php /**PATH /var/www/d3011021/data/www/crm.pubble.systems/resources/views/livewire/user-restoran-edit-item.blade.php ENDPATH**/ ?>