<?php $__env->startSection('content'); ?>
    <div class="ww-100 text-white pb-3 d-flex flex-column">
        <?php if(intval($id) > 0): ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-edit-item', ['userId' => $id])->html();
} elseif ($_instance->childHasBeenRendered('EBvMB5w')) {
    $componentId = $_instance->getRenderedChildComponentId('EBvMB5w');
    $componentTag = $_instance->getRenderedChildComponentTagName('EBvMB5w');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('EBvMB5w');
} else {
    $response = \Livewire\Livewire::mount('user-edit-item', ['userId' => $id]);
    $html = $response->html();
    $_instance->logRenderedChild('EBvMB5w', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php else: ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-edit-item', ['userId' => null])->html();
} elseif ($_instance->childHasBeenRendered('kbb4UKW')) {
    $componentId = $_instance->getRenderedChildComponentId('kbb4UKW');
    $componentTag = $_instance->getRenderedChildComponentTagName('kbb4UKW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('kbb4UKW');
} else {
    $response = \Livewire\Livewire::mount('user-edit-item', ['userId' => null]);
    $html = $response->html();
    $_instance->logRenderedChild('kbb4UKW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.auth-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/d3011021/data/www/crm.pubble.systems/resources/views/components/userEdit.blade.php ENDPATH**/ ?>