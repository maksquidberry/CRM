<div class="col-lg-4 col-md-6 col-sm-6 col-12 mt-2">
    <div class="w-100 h-100 px-3 py-2 <?php if($order->type === 'delivery'): ?> bg-warning <?php endif; ?>   dashboard__items-inner d-flex flex-column align-items-between justify-content-between">
        <div class="w-100 d-flex flex-column">
            <span class="fw-bold dashboard__items-title">№<?php echo e(substr($order->poster_id, -3)); ?> (<?php echo e($order->status); ?>)</span>
            <div class="d-flex flex-column dashboard__items-params my-1">
                <div class="w-100 d-flex justify-content-between mt-2">
                    <span class="dashboard__params-label">Відправлено:</span>
                    <span class="dashboard__params-value"><?php echo e(\Carbon\Carbon::parse($order->start_order)->format('d')); ?> <?php echo e(\Carbon\Carbon::parse($order->start_order)->locale('ru')->format('F')); ?>  <?php echo e(\Carbon\Carbon::parse($order->start_order)->format('H:i')); ?></span>
                </div>
                <div class="w-100 d-flex justify-content-between mt-2">
                    <span class="dashboard__params-label">Кількість позицій:</span>
                    <span class="dashboard__params-value"><?php echo e($order->total_amount); ?> шт</span>
                </div>
                <?php if($order->delivery_date): ?>
                    <div class="w-100 d-flex justify-content-between mt-2">
                        <span class="dashboard__params-label">Дата доставки:</span>
                        <span class="dashboard__params-value"><?php echo e(\Carbon\Carbon::parse($order->delivery_date)->format('d')); ?> <?php echo e(\Carbon\Carbon::parse($order->delivery_date)->locale('ru')->format('F')); ?>  <?php echo e(\Carbon\Carbon::parse($order->delivery_date)->format('H:i')); ?> шт</span>
                    </div>
                <?php endif; ?>
            </div>

            <div class="w-100 d-flex flex-column mt-3">
                <span class="fw-bold">Наіменування:</span>
                <div class="d-flex flex-column">
                    <?php $__currentLoopData = \App\Models\OrdersItem::where('order_id', $order->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product__item d-flex justify-content-between align-items-center">
                            <span class="product__item-name"><?php echo e($item->name); ?></span>
                            <span class="product__item-value fw-bold"><?php echo e($item->amount); ?> шт</span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <div class="w-100 mt-2 d-flex">
            <button class="dashboard__btns-red w-100" wire:click.prevent="endOrderWork">
                <?php switch(auth()->user()->role):
                    case ('packer'): ?>
                        Видати
                        <?php break; ?>

                    <?php default: ?>
                        Завершити
                        <?php break; ?>
                <?php endswitch; ?>
            </button>
        </div>
    </div>
</div>
<?php /**PATH /var/www/d301701/data/www/shaurma.holubets.pp.ua/resources/views/livewire/my-order-item.blade.php ENDPATH**/ ?>