<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('auth-user', [])->html();
} elseif ($_instance->childHasBeenRendered('nj6QAKi')) {
    $componentId = $_instance->getRenderedChildComponentId('nj6QAKi');
    $componentTag = $_instance->getRenderedChildComponentTagName('nj6QAKi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nj6QAKi');
} else {
    $response = \Livewire\Livewire::mount('auth-user', []);
    $html = $response->html();
    $_instance->logRenderedChild('nj6QAKi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/d3011021/data/www/crm.pubble.systems/resources/views/welcome.blade.php ENDPATH**/ ?>