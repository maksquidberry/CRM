<?php $__env->startSection('content'); ?>
    <div class="ww-100 text-white pb-3 d-flex flex-column">
        <?php if(intval($id) > 0): ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('resotran-edit-item', ['userId' => $id])->html();
} elseif ($_instance->childHasBeenRendered('lGVJrTq')) {
    $componentId = $_instance->getRenderedChildComponentId('lGVJrTq');
    $componentTag = $_instance->getRenderedChildComponentTagName('lGVJrTq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lGVJrTq');
} else {
    $response = \Livewire\Livewire::mount('resotran-edit-item', ['userId' => $id]);
    $html = $response->html();
    $_instance->logRenderedChild('lGVJrTq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php else: ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('resotran-edit-item', ['userId' => null])->html();
} elseif ($_instance->childHasBeenRendered('LVKYHqm')) {
    $componentId = $_instance->getRenderedChildComponentId('LVKYHqm');
    $componentTag = $_instance->getRenderedChildComponentTagName('LVKYHqm');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LVKYHqm');
} else {
    $response = \Livewire\Livewire::mount('resotran-edit-item', ['userId' => null]);
    $html = $response->html();
    $_instance->logRenderedChild('LVKYHqm', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.auth-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/crm.pubble.systems/resources/views/components/retoranEdit.blade.php ENDPATH**/ ?>