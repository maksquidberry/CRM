<a wire:poll.keep-alive wire:click.prevent="cleanOrder" style="border-radius: 20px; background:#ff9100; border: 1px solid transparent" class="btn btn-success me-2 d-flex fw-bold align-items-center text-black">
    <span class="ms-2">Очистити замовлення</span>
</a>
<?php /**PATH /var/www/d3011021/data/www/crm.pubble.systems/resources/views/livewire/clean-btn-item.blade.php ENDPATH**/ ?>