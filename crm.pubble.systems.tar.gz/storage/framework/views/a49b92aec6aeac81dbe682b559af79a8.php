<?php $__env->startSection('content'); ?>
    <div class="w-100 text-white pb-3 d-flex flex-column">
        <div class="w-100 d-flex mb-1">
            <a href="<?php echo e(route('users-create')); ?>" style="text-decoration:none;" class="dashboard__btns-yellow px-3">Добавить пользователя</a>
        </div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-list-table', [])->html();
} elseif ($_instance->childHasBeenRendered('sA3bXjY')) {
    $componentId = $_instance->getRenderedChildComponentId('sA3bXjY');
    $componentTag = $_instance->getRenderedChildComponentTagName('sA3bXjY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('sA3bXjY');
} else {
    $response = \Livewire\Livewire::mount('user-list-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('sA3bXjY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <div class="w-100 text-white pb-3 d-flex flex-column">
        <div class="w-100 d-flex mb-1">
            <a href="<?php echo e(route('restoran-create')); ?>" style="text-decoration:none;" class="dashboard__btns-yellow px-3">Добавить заведение</a>
        </div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('restoran-list-table', [])->html();
} elseif ($_instance->childHasBeenRendered('wgV9pUy')) {
    $componentId = $_instance->getRenderedChildComponentId('wgV9pUy');
    $componentTag = $_instance->getRenderedChildComponentTagName('wgV9pUy');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wgV9pUy');
} else {
    $response = \Livewire\Livewire::mount('restoran-list-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('wgV9pUy', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.auth-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/crm.pubble.systems/resources/views/components/userlist.blade.php ENDPATH**/ ?>