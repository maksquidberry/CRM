<div class="w-100 mt-3" wire:poll.keep-alive>
    <div class="w-100 dashboard__table-header d-flex justify-content-between align-items-center">
        <span class="fw-bold text-uppercase fs-4">НОВІ ЗАМОВЛЕННЯ</span>
        <span class="dashboard__table-counter">
            <span>В черзі:</span>
            <span><?php echo e(count($orderList)); ?> шт</span>
        </span>
    </div>

    <div class="w-100 mt-3" >
        <div class="row">
            <?php $__currentLoopData = $orderList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('new-order-item', ['id' => $order->id])->html();
} elseif ($_instance->childHasBeenRendered(time())) {
    $componentId = $_instance->getRenderedChildComponentId(time());
    $componentTag = $_instance->getRenderedChildComponentTagName(time());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(time());
} else {
    $response = \Livewire\Livewire::mount('new-order-item', ['id' => $order->id]);
    $html = $response->html();
    $_instance->logRenderedChild(time(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH /www/wwwroot/crm.pubble.systems/resources/views/livewire/new-orders-tabs.blade.php ENDPATH**/ ?>