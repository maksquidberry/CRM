<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('auth-user', [])->html();
} elseif ($_instance->childHasBeenRendered('vYrTY4i')) {
    $componentId = $_instance->getRenderedChildComponentId('vYrTY4i');
    $componentTag = $_instance->getRenderedChildComponentTagName('vYrTY4i');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vYrTY4i');
} else {
    $response = \Livewire\Livewire::mount('auth-user', []);
    $html = $response->html();
    $_instance->logRenderedChild('vYrTY4i', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/d301701/data/www/shaurma.holubets.pp.ua/resources/views/welcome.blade.php ENDPATH**/ ?>