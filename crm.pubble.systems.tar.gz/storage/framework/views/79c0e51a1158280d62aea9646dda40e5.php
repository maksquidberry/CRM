<div class="col-12 mt-5" wire:poll.keep-alive>
    <div class="w-100">
        <div class="row">
            <div class="col-12 mt-4">
                <h4>Пользователи в группе:</h4>
            </div>

            <?php if(count($groupItems) > 0): ?>
                <?php $__currentLoopData = $groupItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 mt-3">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-restoran-edit-item', ['id' => $itm->id])->html();
} elseif ($_instance->childHasBeenRendered(''.e($itm->id).'')) {
    $componentId = $_instance->getRenderedChildComponentId(''.e($itm->id).'');
    $componentTag = $_instance->getRenderedChildComponentTagName(''.e($itm->id).'');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(''.e($itm->id).'');
} else {
    $response = \Livewire\Livewire::mount('user-restoran-edit-item', ['id' => $itm->id]);
    $html = $response->html();
    $_instance->logRenderedChild(''.e($itm->id).'', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH /var/www/d3011021/data/www/crm.pubble.systems/resources/views/livewire/user-restoran-list.blade.php ENDPATH**/ ?>