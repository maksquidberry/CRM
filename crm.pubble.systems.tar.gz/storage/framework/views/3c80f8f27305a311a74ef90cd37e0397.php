<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="w-100 dashboard__header py-3 px-3">
                <div class="w-100 d-flex justify-content-between">
                    <div>
                        <a href="<?php echo e(route('dashboard')); ?>" class="dashboard__header-link">Головна</a>
                        <a href="<?php echo e(route('orders')); ?>" class="dashboard__header-link">Замолення</a>
                        <a href="<?php echo e(route('dashboard')); ?>" class="dashboard__header-link">Налаштування</a>
                    </div>
                    <div>
                        <a href="<?php echo e(route('exit')); ?>" class="dashboard__header-exit">Вийти</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Projects\DigitalLab\shaurma-crm\resources\views/components/navigation.blade.php ENDPATH**/ ?>