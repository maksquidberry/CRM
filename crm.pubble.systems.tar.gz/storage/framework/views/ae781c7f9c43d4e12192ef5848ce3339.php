<?php $__env->startSection('content'); ?>
    <div class="w-100 text-white pb-3 d-flex flex-column">
        <div class="w-100 d-flex mb-1">
            <a href="<?php echo e(route('users-create')); ?>" style="text-decoration:none;" class="dashboard__btns-yellow px-3">Добавить пользователя</a>
        </div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-list-table', [])->html();
} elseif ($_instance->childHasBeenRendered('kmz5GUy')) {
    $componentId = $_instance->getRenderedChildComponentId('kmz5GUy');
    $componentTag = $_instance->getRenderedChildComponentTagName('kmz5GUy');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('kmz5GUy');
} else {
    $response = \Livewire\Livewire::mount('user-list-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('kmz5GUy', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <div class="w-100 text-white pb-3 d-flex flex-column">
        <div class="w-100 d-flex mb-1">
            <a href="<?php echo e(route('restoran-create')); ?>" style="text-decoration:none;" class="dashboard__btns-yellow px-3">Добавить заведение</a>
        </div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('restoran-list-table', [])->html();
} elseif ($_instance->childHasBeenRendered('onLIzW1')) {
    $componentId = $_instance->getRenderedChildComponentId('onLIzW1');
    $componentTag = $_instance->getRenderedChildComponentTagName('onLIzW1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('onLIzW1');
} else {
    $response = \Livewire\Livewire::mount('restoran-list-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('onLIzW1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.auth-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/d3011021/data/www/crm.pubble.systems/resources/views/components/userlist.blade.php ENDPATH**/ ?>