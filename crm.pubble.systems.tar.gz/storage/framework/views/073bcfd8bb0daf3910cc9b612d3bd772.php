<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('auth-user', [])->html();
} elseif ($_instance->childHasBeenRendered('ynVNyWS')) {
    $componentId = $_instance->getRenderedChildComponentId('ynVNyWS');
    $componentTag = $_instance->getRenderedChildComponentTagName('ynVNyWS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ynVNyWS');
} else {
    $response = \Livewire\Livewire::mount('auth-user', []);
    $html = $response->html();
    $_instance->logRenderedChild('ynVNyWS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/crm.pubble.systems/resources/views/welcome.blade.php ENDPATH**/ ?>