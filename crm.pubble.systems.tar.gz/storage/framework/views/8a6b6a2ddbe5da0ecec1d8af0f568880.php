<?php $__env->startSection('content'); ?>
    <div class="w-100 mb-3 mt-2">
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navigation','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </div>

    <div class="w-100">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-4">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-stats-info', [])->html();
} elseif ($_instance->childHasBeenRendered('Mwscxtk')) {
    $componentId = $_instance->getRenderedChildComponentId('Mwscxtk');
    $componentTag = $_instance->getRenderedChildComponentTagName('Mwscxtk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Mwscxtk');
} else {
    $response = \Livewire\Livewire::mount('user-stats-info', []);
    $html = $response->html();
    $_instance->logRenderedChild('Mwscxtk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
                <div class="col-md-8 col-lg-9">

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\DigitalLab\shaurma-crm\resources\views/components/user/dashboard.blade.php ENDPATH**/ ?>