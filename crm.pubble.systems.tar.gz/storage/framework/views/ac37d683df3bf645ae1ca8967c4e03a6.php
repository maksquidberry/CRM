<?php $__env->startSection('content'); ?>
    <div class="w-100 d-flex flex-column mt-3 mt-md-0">
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="w-100 dashboard__module px-3">
                    <div class="w-100 d-flex flex-column">
                        <h5 class="stats__title m-0 p-0">Статистика замовлень (Сьогодні):</h5>
                        <div class="w-100 d-flex flex-column mt-2">
                            <div class="stats__item d-flex flex-column mt-2">
                                <span class="stats__label">Всього виконано:</span>
                                <span class="stats__value"><?php echo e(count($ordersItemsAllToday)); ?> шт.</span>
                            </div>
                            <div class="stats__item d-flex flex-column mt-2">
                                <span class="stats__label">Середній час виконання готування:</span>
                                <span class="stats__value"><?php echo e($totalCookToday); ?></span>
                            </div>
                            <div class="stats__item d-flex flex-column mt-2">
                                <span class="stats__label">Середній час виконання пакування:</span>
                                <span class="stats__value"><?php echo e($totalPackToday); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="w-100 dashboard__module px-3">
                    <div class="w-100 d-flex flex-column">
                        <h5 class="stats__title m-0 p-0">Статистика замовлень (Всього):</h5>
                        <div class="w-100 d-flex flex-column mt-2">
                            <div class="stats__item d-flex flex-column mt-2">
                                <span class="stats__label">Всього виконано:</span>
                                <span class="stats__value"><?php echo e(count($ordersItemsAll)); ?> шт.</span>
                            </div>
                            <div class="stats__item d-flex flex-column mt-2">
                                <span class="stats__label">Середній час виконання готування:</span>
                                <span class="stats__value"><?php echo e($totalCook); ?></span>
                            </div>
                            <div class="stats__item d-flex flex-column mt-2">
                                <span class="stats__label">Середній час виконання пакування:</span>
                                <span class="stats__value"><?php echo e($totalPack); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-12">
                <div class="w-100 stats__table">
                    <table class="w-100 ">
                        <thead class="stats__table-header">
                            <td style="width: 10%;">#</td>
                            <td style="width: 30%;">Заказ</td>
                            <td style="width: 10%;">Статус</td>
                            <td style="width: 10%;">Виданий</td>
                            <td style="width: 10%;">Позиций</td>
                            <td style="width: 15%;">Час готування</td>
                            <td style="width: 15%;">Час пакування</td>
                        </thead>

                        <tbody class="stats__table-body">
                            <?php $__currentLoopData = $ordersItemsAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="stats__table-item">
                                    <td class="text-center fw-bold"><?php echo e($order->id); ?></td>
                                    <td>Замовлення №<?php echo e(substr($order->poster_id, -3)); ?></td>
                                    <td class="text-center fw-bold">
                                        <?php switch($order->status):
                                            case ('new'): ?>
                                                Новий
                                                <?php break; ?>
                                            <?php case ('cooking'): ?>
                                                Готується
                                                <?php break; ?>
                                            <?php case ('packing'): ?>
                                                Пакується
                                                <?php break; ?>
                                            <?php case ('complete'): ?>
                                                Готовий
                                                <?php break; ?>
                                        <?php endswitch; ?>
                                    </td>
                                    <td class="text-center fw-bold">
                                        <?php if($order->get_user): ?>
                                            Так
                                        <?php else: ?>
                                            Ні
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center fw-bold"><?php echo e($order->total_amount); ?></td>
                                    <td class="text-center fw-bold">
                                        <?php echo e(\Carbon\CarbonInterval::seconds($order->cook_seconds)->cascade()->forHumans(null, true)); ?>

                                    </td>
                                    <td class="text-center fw-bold">
                                        <?php echo e(\Carbon\CarbonInterval::seconds($order->pack_seconds)->cascade()->forHumans(null, true)); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.auth-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/d3011021/data/www/crm.pubble.systems/resources/views/components/user/stats-admin.blade.php ENDPATH**/ ?>