<?php

namespace App\Http\Livewire;

use Livewire\Component;

class RestoranListItemUser extends Component
{
    public function render()
    {
        return view('livewire.restoran-list-item-user');
    }
}
